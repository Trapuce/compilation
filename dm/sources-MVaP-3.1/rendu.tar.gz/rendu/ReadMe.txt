Nous avons fait jusqu'à la boucle while.
